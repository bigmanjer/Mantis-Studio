"""MANTIS Studio application package."""
